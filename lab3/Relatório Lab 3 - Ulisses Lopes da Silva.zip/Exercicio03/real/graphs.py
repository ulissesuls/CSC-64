import matplotlib.pyplot as plt

# Dados (Threads e tempos "comp" em segundos)
threads = [1, 2, 4, 8, 16, 24, 32, 40]
comp = [25.239394, 13.239623, 7.543962, 4.244851, 2.535014, 2.207540, 2.395210, 2.069159]

# Speedup calculado em relação a 1 thread
speedup = [comp[0] / c for c in comp]

# --------- Gráfico 1: Tempo x Threads ---------
plt.figure()
plt.plot(threads, comp, marker='o')
plt.xlabel('Threads')
plt.ylabel('Tempo de computação (s)')
plt.title('Tempo × Threads — Crivo de Eratóstenes')
plt.xticks(threads)
plt.grid(True)

# --------- Gráfico 2: Speedup x Threads ---------
plt.figure()
plt.plot(threads, speedup, marker='o')
plt.xlabel('Threads')
plt.ylabel('Speedup (×)')
plt.title('Speedup × Threads — Crivo de Eratóstenes')
plt.xticks(threads)
plt.grid(True)

plt.tight_layout()
plt.show()

# Salvar as figuras:
plt.savefig('tempo_x_threads.png', dpi=200)
plt.figure(2); plt.savefig('speedup_x_threads.png', dpi=200)
