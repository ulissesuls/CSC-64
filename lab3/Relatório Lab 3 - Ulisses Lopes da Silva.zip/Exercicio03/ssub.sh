#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=40
#SBATCH -p sequana_cpu_dev
#SBATCH -J C_40
#SBATCH --time=00:01:00
#SBATCH --output=/scratch/csc642023/ulisses.silva2/lab3/Exercicio03/Out_Primos_40.txt
#SBATCH --exclusive

cd $SLURM_SUBMIT_DIR
ulimit -s unlimited
export OMP_NUM_THREADS=40
srun -n $SLURM_NTASKS /scratch/csc642023/ulisses.silva2/lab3/Exercicio03/Primos.exe
exit
