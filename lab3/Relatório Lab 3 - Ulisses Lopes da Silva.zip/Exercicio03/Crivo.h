#ifndef __CRIVO__
#define __CRIVO__
#include "Marcador.h"
#include <math.h>


// Crivo: elimina os nao primos do marcador


void Crivo(ptrMarcador M);
#endif
