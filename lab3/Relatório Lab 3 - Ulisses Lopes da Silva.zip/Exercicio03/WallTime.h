#ifndef __WALL_TIME__
#define __WALL_TIME__

#include <sys/time.h>

double WallTime(void);

#endif
